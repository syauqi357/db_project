<?php

$host = "localhost"; //Host Server
$user = "root"; //user login
$pass = ""; //pass login
$db = "itb"; //nama database
$conn = mysqli_connect($host, $user, $pass, $db) or die ("Koneksi Gagal");


?>