<?php

include "koneksi.php";
$nim = $_GET['nim'];

$conn = mysqli_connect($host, $user, $pass, $db);
$mysqli = "DELETE FROM mhs WHERE nim = $nim";
$result = mysqli_query($conn, $mysqli);
$update_message = "Update has all set!";



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="MainStyle.css">
    <style>
        .card-container {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .card-a {
            background: #fff;
            width: 393px;

            border-radius: 11px;
            background: #fff;
            padding: 12px;
            border: #e7e7e7 1.78px solid;
        }

        .content {
            display: flex;
            align-items: center;
            padding: 6px 20px 6px 20px;
            gap: 2rem;
            height: 105px;
            flex-shrink: 0;
        }

        .content h3 {
            font-size: 20px;

            font-weight: 500;
        }

        .icon-danger {
            width: 68px;
        }

        .icon-danger svg {
            fill: #cc0c39;
            transition: all 0.2s ease-in-out;
        }

        .icon-danger svg:hover {
            transform: scale(1.1);
        }

        .button--actiontrigger {
            display: flex;
            padding: 12px;
            justify-content: space-around;
        }

        #GetAccess button {
            display: flex;
            padding: 14px 50px 14px 50px;
            justify-content: center;
            align-items: center;
            border-radius: 4px;
            background: #e7e7e7;
            border: none;
        }

        #GetAccess button:hover {
            background-color: #d2d2d2;
        }

        #cancelAccess button {
            display: flex;
            padding: 14px 63px;
            align-items: flex-end;
            gap: 10px;
            border-radius: 4px;
            background: #f10c43;
            border: none;
            color: #fff;
        }

        #cancelAccess button:hover {
            background-color: #cc0c39;
        }
    </style>
</head>

<body>
    <div class="card-container">
        <div class="card-a">
            <div class="content">
                <div class="icon-danger">
                    <!-- svg -->
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.7.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                        <path d="M135.2 17.7C140.6 6.8 151.7 0 163.8 0L284.2 0c12.1 0 23.2 6.8 28.6 17.7L320 32l96 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 96C14.3 96 0 81.7 0 64S14.3 32 32 32l96 0 7.2-14.3zM32 128l384 0 0 320c0 35.3-28.7 64-64 64L96 512c-35.3 0-64-28.7-64-64l0-320zm96 64c-8.8 0-16 7.2-16 16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16zm96 0c-8.8 0-16 7.2-16 16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16zm96 0c-8.8 0-16 7.2-16 16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16z" />
                    </svg>
                </div>
                <div class="text_desc">
                    <h3><?php echo $update_message; ?></h3>
                </div>
            </div>
            <div class="button--actiontrigger">
                <!-- <div id="GetAccess"></div> -->
                <div id="cancelAccess">
                    <a href="panel.php"><button>Get access</button></a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>