<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Modal Form</title>
  <link rel="stylesheet" href="MainStyle.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Instrument+Sans:ital,wght@0,400..700;1,400..700&family=Inter:ital,opsz,wght@0,14..32,719;1,14..32,719&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Instrument+Sans:ital,wght@0,400..700;1,400..700&family=Inter:ital,opsz@0,14..32;1,14..32&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Doto:wght@600&family=Instrument+Sans:ital,wght@0,400..700;1,400..700&family=Inter:ital,opsz@0,14..32;1,14..32&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Funnel+Sans:ital,wght@0,300;1,300&display=swap" rel="stylesheet">
  <style>
    .disclaimer {
      display: flex;
      gap: 12px;
      align-items: center;
      color: red;
      opacity: 40%;
    }

    .disclaimer svg {
      fill: red;
    }
  </style>
</head>

<body>
  <?php

  include "koneksi.php";

  $nim = $_GET['nim'];
  $nama = $_GET['nama'];
  $alamat = $_GET['alamat'];
  $jenis_kelamin = $_GET['jenis_kelamin'];

  ?>
  <div class="containMid">


    <form method="post" action="koreksiupdate.php" class="formMain">
      <h1>
        Edit data
      </h1>
      <p>
        edit data di sini!
      </p>
      <div class="inputBoxCh">

        <?php echo "Nim : <input type='text'  name='nim' readonly value='" . $nim . "'>"; ?>
      </div>
      <div class="disclaimer">
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#5f6368">
          <path d="M115.22-110.39q-14.96 0-26.83-7.37-11.88-7.36-18.48-19.41-6.69-11.83-7.19-25.78-.5-13.94 7.19-27.22L433.7-820q7.69-13.39 20.36-19.8 12.66-6.42 26-6.42 13.33 0 25.94 6.42 12.61 6.41 20.3 19.8l363.79 629.83q7.69 13.28 7.19 27.22-.5 13.95-7.19 25.78-6.7 11.82-18.52 19.3-11.83 7.48-26.79 7.48H115.22Zm76.91-97.52h575.74L480-704.17 192.13-207.91ZM480-241.7q17.57 0 30.2-12.63 12.63-12.63 12.63-30.19 0-17.57-12.63-29.92-12.63-12.34-30.2-12.34t-30.2 12.34q-12.63 12.35-12.63 29.92 0 17.56 12.63 30.19 12.63 12.63 30.2 12.63Zm0-118.3q17 0 28.5-11.5T520-400v-113.78q0-17-11.5-28.5t-28.5-11.5q-17 0-28.5 11.5t-11.5 28.5V-400q0 17 11.5 28.5T480-360Zm0-96.04Z" />
        </svg>
        <p>
          NIM tidak dapat di ganti
        </p>
      </div>
      <div class="inputBoxCh">

        <?php echo "Nama : <input type='text' name='nama' value='" . $nama . "'>"; ?>
      </div>
      <div class="inputBoxCh">

        <?php echo "Alamat : <input type='text' name='alamat' value='" . $alamat . "'>"; ?>
      </div>
      <div class="inputBoxCh">

        <?php echo "Jenis Kelamin : <input type='text' placeholder='P / L' maxlength='1' name='jenis_kelamin' value='" . $jenis_kelamin . "'>"; ?>
      </div>
      <div class="disFlexEdit">

        <button type="submit" value="Update" class="buttonStylingEditData">simpan data</button>
        <a href="panel.php">Kembali</a>
      </div>
    </form>
  </div>




</body>

</html>