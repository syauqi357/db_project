<?php

include "koneksi.php";
$nim = $_REQUEST['nim'];
$nama = $_REQUEST['nama'];
$alm = $_REQUEST['alamat'];
$jk = $_REQUEST['jenis_kelamin'];
$conn = mysqli_connect($host, $user, $pass, $db);
$mysqli = "UPDATE mhs SET nama='" . $nama . "',alamat='" . $alm . "',jenis_kelamin='" . $jk . "' WHERE nim='$nim'";
$result = mysqli_query($conn, $mysqli);
$update_message = "Update has all set!";
mysqli_close($conn);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Status</title>
    <link rel="stylesheet" href="MainStyle.css">
    <style>
        .card-container {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .card-a {
            background: #fff;
            width: 393px;

            border-radius: 11px;
            background: #fff;
            padding: 12px;
            border: #e7e7e7 1.78px solid;
        }

        .content {
            display: flex;
            align-items: center;
            padding: 6px 20px 6px 20px;
            gap: 2rem;
            height: 105px;
            flex-shrink: 0;
        }

        .content h3 {
            font-size: 20px;

            font-weight: 500;
        }

        .icon-danger {
            width: 90px;
        }

        .icon-danger svg {
            transition: all 0.2s ease-in-out;
        }

        .icon-danger svg:hover {
            transform: scale(1.1);
        }

        .button--actiontrigger {
            display: flex;
            padding: 12px;
            justify-content: space-around;
        }

        #GetAccess button {
            display: flex;
            padding: 14px 50px 14px 50px;
            justify-content: center;
            align-items: center;
            border-radius: 4px;
            background: #e7e7e7;
            border: none;
        }

        #GetAccess button:hover {
            background-color: #d2d2d2;
        }

        #cancelAccess button {
            display: flex;
            padding: 14px 63px;
            align-items: flex-end;
            gap: 10px;
            border-radius: 4px;
            background: #f10c43;
            border: none;
            color: #fff;
        }

        #cancelAccess button:hover {
            background-color: #cc0c39;
        }
    </style>


</head>

<body>




    <div class="card-container">
        <div class="card-a">
            <div class="content">
                <div class="icon-danger">
                    <!-- svg -->
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.7.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                        <path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" />
                    </svg>
                </div>
                <div class="text_desc">
                    <h3><?php echo $update_message; ?></h3>
                </div>
            </div>
            <div class="button--actiontrigger">
                <!-- <div id="GetAccess"></div> -->
                <div id="cancelAccess">
                    <a href="panel.php"><button>Get access</button></a>
                </div>
            </div>
        </div>
    </div>


</body>

</html>